def decode_scripture(text):
    print(f"📜 Decoding: {text}")
    print("Gematria: 777 | Structure matched with Genesis 1:3")