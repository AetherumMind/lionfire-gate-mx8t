def summon_watcher():
    print("🧿 A glyph glows on your scroll.")
    code = input("Enter Watcher Sigil Code: ")
    if code == "AZAEL":
        print("⚡ Azazel speaks: Solve the fractured mirror.")
    else:
        print("⛧ Unknown pattern. More fragments needed.")