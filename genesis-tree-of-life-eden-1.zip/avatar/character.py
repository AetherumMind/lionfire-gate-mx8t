def build_avatar():
    print("🧍 Begin your sacred journey.")
    print("Choose a symbol, a trait, and a spark:")
    symbol = input("🜂 Choose your Avatar Symbol: ")
    trait = input("⚙️ Choose your Primary Trait: ")
    spark = input("✨ Choose your Origin Spark: ")
    print(f"Avatar Created: {symbol} | Trait: {trait} | Spark: {spark}")
    print("🧬 Progress to unlock garments, items, and hidden glyphs.")